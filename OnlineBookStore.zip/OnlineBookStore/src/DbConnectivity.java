/*
 
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;  
import javax.swing.JOptionPane;

public class DbConnectivity {
    
   private static DbConnectivity dbObject;
   Connection con;

   private DbConnectivity() {      
   }

   public static DbConnectivity getInstance() {

      // create object if it's not already created
      if(dbObject == null) {
         dbObject = new DbConnectivity();
      }

       // returns the singleton object
       return dbObject;
   }

   public Connection getConnection() {
        try{  
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  

//here sonoo is database name, root is username and password 

    try{
         con = DriverManager.getConnection(  "jdbc:sqlserver://DESKTOP-EM6BMB7\\SQLEXPRESS;databaseName=onlinebookstore1;integratedSecurity=true");
        //here sonoo is database name, root is username and password
   
        //Scanner sc = new Scanner(System.in);
       // stmt.executeUpdate("INSERT INTO Registration(username,password,email,contact) VALUES(?,?,?,?)");
    }catch(Exception e)
    { System.out.println(e);}
} 
    catch(Exception e){ System.out.println(e);

}   return con;
   }

}
